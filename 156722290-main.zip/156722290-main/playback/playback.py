def main():
    # Prompt the user for input
    text = input("Enter text: ")

    # Replace spaces with three periods
    modified_text = text.replace(" ", "...")

    # Print the modified text
    print(modified_text)

main()
