Chaptor 0:

The main takeawaysfrom assigment:

1: User Input and Output: How to prompt for user input using input(). Displaying output to the user with print() and formatting strings with f-string.

2: String Manipulation: Converting strings to different cases (e.g., lower case in indoor.py). Replacing characters or substrings in a string (e.g., replacing spaces with periods in playback.py), 
    which is usefull in lots of files in wcb Handling and transforming strings based on specific patterns (e.g., converting emoticons to emojis in faces.py).

3: Basic Mathematical Operations: Performing arithmetic calculations (e.g., the E=mc^2 calculation in einstein.py). Using mathematical concepts to solve practical problems (e.g., calculating tips in tip.py).

4:Data Type Conversion: Converting between different data types (e.g., strings to floats). Understanding the importance of correct data types in calculations.

4: String Formatting for Output: Formatting numerical output to a fixed number of decimal places (e.g., formatting the tip amount in tip.py).
