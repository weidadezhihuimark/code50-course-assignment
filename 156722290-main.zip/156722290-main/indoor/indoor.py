def main():

    user_input = input ("What's your input? ")

    # Convert the input into lowercase
    lowercase_input = user_input.lower()

    # Output the lowercase

    print(lowercase_input)

main()
